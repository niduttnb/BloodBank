<ul class="nav">
			<li class="active"><a href="index.php">Home</a></li>	
			<li><a href="registration.php">Register</a></li>            
			<li><a href="requests.php">Request</a></li>
            <li><a href="viewrequest.php">help</a></li>
            <li><a href="camps.php">Our camps</a></li>
            <li><a href="login.php">log In</a></li>
            <li><a href="search.php">Search</a></li>
            <li><a href="contact.php">Contact Us</a></li>
            </ul>